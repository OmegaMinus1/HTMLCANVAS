﻿var theCanvas;
var theCanvasAspectRatio = 0;
var gl;
var iTime_U;
var iResolution_U;
var TotalSeconds = 0.0;
var lastElapsedTime = 0.0;



